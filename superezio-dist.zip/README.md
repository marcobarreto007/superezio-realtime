Superezio Realtime

Este arquivo é servido em produção apenas para evitar 404 quando o RAG tenta ler o README. Veja o código-fonte local para a versão completa.

